
#3d object scanner using intel realsense D435if by R.DINESH KUMAR (Embedded intern)

#*******************************************************************>>>>>               READ ME                <<<<*****************************************************************************************************************************************************************************************

"""" *Done it in the duration of 2 month internship
     *I had provided the explanation of every line of the code in the comments and prerequisite for running the code and using turning table.some may be wrong in the comments that will be for my understanding or with my understanding.

     * im going provide three set of code and a executable file with the require packages that will be a complete software but it will be slow and not responding every time
     *this current_final.py is for manual scanning it will capture when the photo when the enter button is pressed.
     *another code called file2.py(maybe i will rename when i push to the git) is for automatic scanning once the code is being ran,the code will start scanning the whole 360 degree for a interval of 1 second per given degree.
     *another code called opencv-feature-detection.py(maybe i will rename when i push to the git) this code have a gui interface and a comport reading feature in the code u have to run the turn table code in the arduino ide and start scan.

Prerequisite for using this code:
    *Stable pc or laptop with windows or linux system ( i used 8gb ram laptop and windows 11 coz i faced some depth camera detection issue in ubuntu 20.04)
    *vscode or pycharm for running and writing the code ( i used pycharm and i prefer pycharm coz it will be easy to create environment and installing packages but it will sometimes give lag or crash.)
    *use python 3.9 for running this code ,otherwise u can't install some necessary packages (u may use other versions of python but i had tried every version)
    *u can meshlab,blender or other software for viewing the stl file generated.

prerequisite for turn table:
    *arduino ide stable version
    *arduino uno or mega (i used arduino mega2560 i will provide the arduino code in the git )
    *stepper motor nema-17 39mm,l293 driver,push button,breadboard,jumper cables etc..
    *3d printed connector and camera mount for stepper motor to turning table.
    *there is a object-table calculation there for aligning the camera in a perfect manner for that (i will provide object-table calculation for this scanner and with a suitable diagram.in the git)

"""
#******************************************************************************************************************************************************************************************************************************************************************


import serial #for using serial function for arduino ide with device's ports i haven't used serial in this code but i used in other code
import keyboard #for using keyboard function like enter to take photo
import pyrealsense2 as rs #for intel realsense camera user's there is a inbuilt library given by intel for using depth camera functions like rgb, depth module etc
import open3d as o3d #for using 3d point cloud and mesh creation im using open3d library.
import numpy as np #for using basic mathematic functions
import cv2 #for computer vision features used like measuring the camera to object distance and object dimensions.
import time #not used in this code,it is used for time features like date,time etc
import threading #threading is used to thread a function it is used to optimize the code.

class Scan(): #creating a class called called Scan
    def __init__(self, width, height, framerate, autoexposureFrames, backDistance): #im creating a function with self, width, height, framerate, autoexposureFrames, backDistance ,it indicates the self for depth camera.
        self.width = width #width of the depth camera vision
        self.height = height #height of the depth camera vision
        self.framerate = framerate #framerate of the depth camera vision
        self.backDistance = backDistance #it is distance between camera and object.
        self.distance = backDistance / 100 #it is divided by 100 for getting it in the seconds.
        self.autoexposureFrames = autoexposureFrames #This allows the instance to store and manage the autoexposure frames setting.
        self.main_pcd = o3d.geometry.PointCloud() #using open3d library to make point cloud

        self.pipe = rs.pipeline() #realsense depth camera pipeline started.
        self.config = rs.config() #starting realsense with configuration like rgb module, depth module etc..
        self.config.enable_stream(rs.stream.color, self.width, self.height, rs.format.any, self.framerate) #starting to stream color with the width,height,format and framerate given
        self.config.enable_stream(rs.stream.depth, self.width, self.height, rs.format.any, self.framerate) #starting to stream using depth configuration

        self.depth_to_disparity = rs.disparity_transform(True) #function that converts depth images to disparity images
        self.disparity_to_depth = rs.disparity_transform(False) #disparity to depth is negative
        self.dec_filter = rs.decimation_filter() #used to reduce the amount of data in the depth stream, effectively decreasing the resolution of the depth image to improve performance.
        self.temp_filter = rs.temporal_filter() #used to reduce temporal noise and smooth the depth data over time.
        self.spat_filter = rs.spatial_filter() #used to smooth the depth image spatially, reducing noise and small artifacts while preserving edges
        self.hole_filter = rs.hole_filling_filter() #used to fill small gaps (holes) in the depth data where no depth information is available.
        self.threshold = rs.threshold_filter(0.17, 0.4) #used to eliminate depth values that fall outside the specified range here in this code i had used 0.17 as minimum and 0.4 as maximum, helping to focus on relevant depth information.

        self.dtr = np.pi / 180 #used to convert degrees to radians
        self.bbox = o3d.geometry.AxisAlignedBoundingBox((-0.13, -0.13, 0), (0.13, 0.13, 0.2)) #(AABB) using the Open3D library. This bounding box is defined by its minimum (-0.13, -0.13, 0)and maximum (0.13, 0.13, 0.2) corner coordinates.

    def startPipeline(self): #startPipeline method im trying to define likely belongs to a class
        self.pipe.start(self.config) #pipeline is started with the given configuration
        self.align = rs.align(rs.stream.color) #aligning with realsense color stream(camera feed) after this process  i will add distance measuring module in this code.
        print("Pipeline started") #printing pipeline is started when the rgb came on line

    def stopPipeline(self): #i m creating a function called stopPipeline to stop the depth camera
        self.pipe.stop() #this line will stop the depth camera streaming.
        self.pipe = None #pipeline had stopped
        self.config = None #when the pipeline is stopped, the configuration will stop too.
        cv2.destroyAllWindows() #by using i m closing the open3d window and camera stream window.
        print("Pipeline stopped") #printing the statement that pipeline is stopped.

    def takeFoto(self): #i m creating function called takefoto
        print("Photo taken!") #printing that photo taken
        for i in range(self.autoexposureFrames): #creating a for loop in the range of the settings given in the autoexposureFrames
            self.frameset = self.pipe.wait_for_frames() #get a set of frames from the pipeline

        self.frameset = self.pipe.wait_for_frames() #get a set of frames from the pipeline
        self.frameset = self.align.process(self.frameset) #ensures that the depth and color images are spatially aligned
        self.profile = self.frameset.get_profile() #obtain the profile of the frameset which consist resolution,framerate,backdistance etc..
        self.depth_intrinsics = self.profile.as_video_stream_profile().get_intrinsics() #obtaining the depth intrinsics(focal length, principal point, and distortion model etc..) from the stream profile
        self.w, self.h = self.depth_intrinsics.width, self.depth_intrinsics.height #extract the width and height from the depth intrinsics
        self.fx, self.fy = self.depth_intrinsics.fx, self.depth_intrinsics.fy #transferring the depth intrinsic from self.depth_intrinsics.fx and self.depth_intrinsics.fy to self.fx and self.fy, respectively.
        self.px, self.py = self.depth_intrinsics.ppx, self.depth_intrinsics.ppy #self.px, self.py = self.depth_intrinsics.ppx, self.depth_intrinsics.ppy is assigning the values of ppx and ppy

        self.color_frame = self.frameset.get_color_frame()
        self.depth_frame = self.frameset.get_depth_frame()

        self.intrinsic = o3d.camera.PinholeCameraIntrinsic(self.w, self.h, self.fx, self.fy, self.px, self.py)
        self.depth_image = np.asanyarray(self.depth_frame.get_data())
        self.color_image = np.asanyarray(self.color_frame.get_data())

    def processFoto(self, angle):
        print(f"Processing photo at angle {angle} degrees")
        self.angle = angle
        self.depth_frame_open3d = o3d.geometry.Image(self.depth_image)
        self.color_frame_open3d = o3d.geometry.Image(self.color_image)

        self.rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(self.color_frame_open3d,
                                                                             self.depth_frame_open3d,
                                                                             convert_rgb_to_intensity=False)
        self.pcd = o3d.geometry.PointCloud.create_from_rgbd_image(self.rgbd_image, self.intrinsic)
        self.pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))
        self.pcd.orient_normals_towards_camera_location(camera_location=np.array([0., 0., 0.]))
        self.getCameraLocation()
        self.rMatrix()
        self.pcd.rotate(self.R, (0, 0, 0))
        self.pcd.translate((self.x, self.y, self.z))
        self.pcd = self.pcd.crop(self.bbox)
        self.pcd, self.ind = self.pcd.remove_statistical_outlier(nb_neighbors=100, std_ratio=2)
        self.main_pcd = self.main_pcd + self.pcd
        self.measureDimensions()

    def getPointcloud(self):
        return self.main_pcd

    def giveImageArray(self):
        return self.color_image

    def getCameraLocation(self):
        self.x = np.sin(self.angle * self.dtr) * self.distance - np.cos(self.angle * self.dtr) * 0.035
        self.y = -np.cos(self.angle * self.dtr) * self.distance - np.sin(self.angle * self.dtr) * 0.035
        self.z = 0.165
        self.o = self.angle
        self.a = 112.5
        self.t = 0

    def rMatrix(self):
        self.o = self.o * self.dtr
        self.a = (-self.a) * self.dtr
        self.t = self.t * self.dtr
        self.R = [[np.cos(self.o) * np.cos(self.t) - np.cos(self.a) * np.sin(self.o) * np.sin(self.t),
                   -np.cos(self.o) * np.sin(self.t) - np.cos(self.a) * np.cos(self.t) * np.sin(self.o),
                   np.sin(self.o) * np.sin(self.a)],
                  [np.cos(self.t) * np.sin(self.o) + np.cos(self.o) * np.cos(self.a) * np.sin(self.t),
                   np.cos(self.o) * np.cos(self.a) * np.cos(self.t) - np.sin(self.o) * np.sin(self.t),
                   -np.cos(self.o) * np.sin(self.a)],
                  [np.sin(self.a) * np.sin(self.t), np.cos(self.t) * np.sin(self.a), np.cos(self.a)]]

    def makeSTL(self, kpoints, stdRatio, depth, iterations):
        self.stl_pcd = self.main_pcd
        self.stl_pcd = self.stl_pcd.uniform_down_sample(every_k_points=kpoints)
        self.stl_pcd, self.ind = self.stl_pcd.remove_statistical_outlier(nb_neighbors=100, std_ratio=stdRatio)
        self.bbox1 = o3d.geometry.AxisAlignedBoundingBox((-0.13, -0.13, 0), (0.13, 0.13, 0.01))
        self.bottom = self.stl_pcd.crop(self.bbox1)
        try:
            self.hull, self._ = self.bottom.compute_convex_hull()
            self.bottom = self.hull.sample_points_uniformly(number_of_points=10000)
            self.bottom.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))
            self.bottom.orient_normals_towards_camera_location(camera_location=np.array([0., 0., -10.]))
            self.bottom.paint_uniform_color([0, 0, 0])
            self._, self.pt_map = self.bottom.hidden_point_removal([0, 0, -1], 1)
            self.bottom = self.bottom.select_by_index(self.pt_map)
            self.stl_pcd = self.stl_pcd + self.bottom
        except:
            print("No bottom could be made")
            pass
        finally:
            self.mesh, self.densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(self.stl_pcd, depth=depth)
            self.mesh = self.mesh.filter_smooth_simple(number_of_iterations=iterations)
            self.mesh.scale(1000, center=(0, 0, 0))
            self.mesh.compute_vertex_normals()

        return self.mesh

    def measureDimensions(self):
        bbox = self.main_pcd.get_axis_aligned_bounding_box()
        min_bound = bbox.get_min_bound()
        max_bound = bbox.get_max_bound()
        dimensions = max_bound - min_bound
        length, breadth, height = dimensions[0], dimensions[1], dimensions[2]
        print(f"Dimensions of the object - Length: {length:.2f} m, Breadth: {breadth:.2f} m, Height: {height:.2f} m") #printing the dimensions of the object

    def visualize(self):
        o3d.visualization.draw_geometries([self.main_pcd])

    def showCameraFeed(self):
        while True:
            frames = self.pipe.wait_for_frames()
            color_frame = frames.get_color_frame()
            depth_frame = frames.get_depth_frame()

            if not color_frame or not depth_frame:
                continue

            color_image = np.asanyarray(color_frame.get_data())
            depth_image = np.asanyarray(depth_frame.get_data())
            center_x, center_y = int(self.width / 2), int(self.height / 2)
            distance = depth_frame.get_distance(center_x, center_y)
            cv2.putText(color_image, f'Distance: {distance:.2f} m', (center_x - 100, center_y - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)
            cv2.circle(color_image, (center_x, center_y), 5, (0, 255, 0), -1)
            cv2.imshow('Camera Feed', color_image) #a screen is shown as camera feed with color image,it is shown using cv2 "imshow" keyword
            if cv2.waitKey(1) & 0xFF == ord('q'): #if q key is pressed it will stop camera feed screen/window
                break #breaking the process
width = 640  #width of the frame is given by me as default
height = 480 #height of the frame is given by me as default
framerate = 30  #framerate is given by me as default
autoexposureFrames = 10  #autoexposureFrames is given by me as a default

backDistance = float(input("Enter the scanning distance (backDistance in cm): ")) #this line get backdistance as input from the user store it as backDistance

scan = Scan(width, height, framerate, autoexposureFrames, backDistance) #Scan function used with the given configuration and stored in a variable called scan
scan.startPipeline() #starting the depth camera scaning
camera_feed_thread = threading.Thread(target=scan.showCameraFeed) #thread is created us
camera_feed_thread.start() #threading variable is initializing using start()
angles = [0.0, 7.5, 15.0, 22.5, 30.0, 37.5, 45.0, 52.5, 60.0, 67.5, 75.0, 82.5, 90.0, 97.5, 105.0, 112.5, 120.0, 127.5, 135.0, 142.5, 150.0, 157.5, 165.0, 172.5, 180.0, 187.5, 195.0, 202.5, 210.0, 217.5, 225.0, 232.5, 240.0, 247.5, 255.0, 262.5, 270.0, 277.5, 285.0, 292.5, 300.0, 307.5, 315.0, 322.5, 330.0, 337.5, 345.0, 352.5
] #the angles given in this set will be used for degree turning and photo capture.
for angle in angles: #making a for loop for the angles with name of angle
    input("Press any key to take photo at angle {}: ".format(angle)) #this line will take a key press as input to take photo in the angle.
    scan.takeFoto() #this will call the takeFoto function it will take angles capture
    scan.processFoto(angle) #scanning the photo taken with the angle.
    scan.visualize() #visualizing the scanned data
pointcloud = scan.getPointcloud() #this keyword will scan and save the pointcloud in the variable called pointcloud
stl = scan.makeSTL(kpoints=10, stdRatio=0.5, depth=8, iterations=5) #creating stl with this configurations given
o3d.io.write_triangle_mesh("output.stl", stl) #creating stl with the help of open3d with the keyword write triangle mesh

scan.stopPipeline() #depth camera will be stopped
print("3D scanning completed and saved as output.stl") #printing that scanning is complete and saved as output.stl, the file can be located in the location of the python file
