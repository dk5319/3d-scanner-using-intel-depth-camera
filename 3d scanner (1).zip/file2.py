import serial  # pip install pyserial
import keyboard  # pip install keyboard
import pyrealsense2 as rs
import open3d as o3d  # pip install open3d
import numpy as np  # pip install numpy
import cv2  # pip install opencv-python
import time
import threading

class Scan():
    def __init__(self, width, height, framerate, autoexposureFrames, backDistance):
        self.width = width
        self.height = height
        self.framerate = framerate
        self.backDistance = backDistance  # Initialize the backDistance attribute
        self.distance = backDistance / 100  # Convert cm to meters and initialize the distance attribute
        self.autoexposureFrames = autoexposureFrames
        self.main_pcd = o3d.geometry.PointCloud()

        self.pipe = rs.pipeline()
        self.config = rs.config()
        self.config.enable_stream(rs.stream.color, self.width, self.height, rs.format.any, self.framerate)
        self.config.enable_stream(rs.stream.depth, self.width, self.height, rs.format.any, self.framerate)

        # Post-processing filters
        self.depth_to_disparity = rs.disparity_transform(True)
        self.disparity_to_depth = rs.disparity_transform(False)
        self.dec_filter = rs.decimation_filter()
        self.temp_filter = rs.temporal_filter()
        self.spat_filter = rs.spatial_filter()
        self.hole_filter = rs.hole_filling_filter()
        self.threshold = rs.threshold_filter(0.17, 0.4)

        self.dtr = np.pi / 180
        self.bbox = o3d.geometry.AxisAlignedBoundingBox((-0.13, -0.13, 0), (0.13, 0.13, 0.2))

    def startPipeline(self):
        self.pipe.start(self.config)
        self.align = rs.align(rs.stream.color)
        print("Pipeline started")

    def stopPipeline(self):
        self.pipe.stop()
        self.pipe = None
        self.config = None
        cv2.destroyAllWindows()
        print("Pipeline stopped")

    def takeFoto(self):
        print("Photo taken!")
        for i in range(self.autoexposureFrames):
            self.frameset = self.pipe.wait_for_frames()

        self.frameset = self.pipe.wait_for_frames()
        self.frameset = self.align.process(self.frameset)
        self.profile = self.frameset.get_profile()
        self.depth_intrinsics = self.profile.as_video_stream_profile().get_intrinsics()
        self.w, self.h = self.depth_intrinsics.width, self.depth_intrinsics.height
        self.fx, self.fy = self.depth_intrinsics.fx, self.depth_intrinsics.fy
        self.px, self.py = self.depth_intrinsics.ppx, self.depth_intrinsics.ppy

        self.color_frame = self.frameset.get_color_frame()
        self.depth_frame = self.frameset.get_depth_frame()

        self.intrinsic = o3d.camera.PinholeCameraIntrinsic(self.w, self.h, self.fx, self.fy, self.px, self.py)
        self.depth_image = np.asanyarray(self.depth_frame.get_data())
        self.color_image = np.asanyarray(self.color_frame.get_data())

    def processFoto(self, angle):
        print(f"Processing photo at angle {angle} degrees")
        self.angle = angle
        self.depth_frame_open3d = o3d.geometry.Image(self.depth_image)
        self.color_frame_open3d = o3d.geometry.Image(self.color_image)

        self.rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(self.color_frame_open3d,
                                                                             self.depth_frame_open3d,
                                                                             convert_rgb_to_intensity=False)
        self.pcd = o3d.geometry.PointCloud.create_from_rgbd_image(self.rgbd_image, self.intrinsic)
        self.pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))
        self.pcd.orient_normals_towards_camera_location(camera_location=np.array([0., 0., 0.]))
        self.getCameraLocation()
        self.rMatrix()
        self.pcd.rotate(self.R, (0, 0, 0))
        self.pcd.translate((self.x, self.y, self.z))
        self.pcd = self.pcd.crop(self.bbox)
        self.pcd, self.ind = self.pcd.remove_statistical_outlier(nb_neighbors=100, std_ratio=2)
        self.main_pcd += self.pcd

    def getPointcloud(self):
        return self.main_pcd

    def giveImageArray(self):
        return self.color_image

    def getCameraLocation(self):
        self.x = np.sin(self.angle * self.dtr) * self.distance - np.cos(self.angle * self.dtr) * 0.035
        self.y = -np.cos(self.angle * self.dtr) * self.distance - np.sin(self.angle * self.dtr) * 0.035
        self.z = 0.165
        self.o = self.angle
        self.a = 112.5
        self.t = 0

    def rMatrix(self):
        self.o = self.o * self.dtr
        self.a = (-self.a) * self.dtr
        self.t = self.t * self.dtr
        self.R = [[np.cos(self.o) * np.cos(self.t) - np.cos(self.a) * np.sin(self.o) * np.sin(self.t),
                   -np.cos(self.o) * np.sin(self.t) - np.cos(self.a) * np.cos(self.t) * np.sin(self.o),
                   np.sin(self.o) * np.sin(self.a)],
                  [np.cos(self.t) * np.sin(self.o) + np.cos(self.o) * np.cos(self.a) * np.sin(self.t),
                   np.cos(self.o) * np.cos(self.a) * np.cos(self.t) - np.sin(self.o) * np.sin(self.t),
                   -np.cos(self.o) * np.sin(self.a)],
                  [np.sin(self.a) * np.sin(self.t), np.cos(self.t) * np.sin(self.a), np.cos(self.a)]]

    def makeSTL(self, kpoints, stdRatio, depth, iterations):
        stl_pcd = self.main_pcd.uniform_down_sample(every_k_points=kpoints)
        stl_pcd, _ = stl_pcd.remove_statistical_outlier(nb_neighbors=100, std_ratio=stdRatio)
        bbox1 = o3d.geometry.AxisAlignedBoundingBox((-0.13, -0.13, 0), (0.13, 0.13, 0.01))
        bottom = stl_pcd.crop(bbox1)
        try:
            hull, _ = bottom.compute_convex_hull()
            bottom = hull.sample_points_uniformly(number_of_points=10000)
            bottom.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))
            bottom.orient_normals_towards_camera_location(camera_location=np.array([0., 0., -10.]))
            bottom.paint_uniform_color([0, 0, 0])
            _, pt_map = bottom.hidden_point_removal([0, 0, -1], 1)
            bottom = bottom.select_by_index(pt_map)
            stl_pcd += bottom
        except:
            print("No bottom could be made")
            pass
        finally:
            mesh, _ = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(stl_pcd, depth=depth)
            mesh = mesh.filter_smooth_simple(number_of_iterations=iterations)
            mesh.scale(1000, center=(0, 0, 0))
            mesh.compute_vertex_normals()

        return mesh

    def measureDimensions(self):
        bbox = self.main_pcd.get_axis_aligned_bounding_box()
        min_bound = bbox.get_min_bound()
        max_bound = bbox.get_max_bound()
        dimensions = max_bound - min_bound
        length, breadth, height = dimensions[0], dimensions[1], dimensions[2]
        print(f"Dimensions of the object - Length: {length:.2f} m, Breadth: {breadth:.2f} m, Height: {height:.2f} m")

    def showCameraFeed(self):
        while True:
            frames = self.pipe.wait_for_frames()
            color_frame = frames.get_color_frame()
            depth_frame = frames.get_depth_frame()

            if not color_frame or not depth_frame:
                continue

            color_image = np.asanyarray(color_frame.get_data())
            depth_image = np.asanyarray(depth_frame.get_data())

            # Get the distance at the center of the frame
            center_x, center_y = int(self.width / 2), int(self.height / 2)
            distance = depth_frame.get_distance(center_x, center_y)

            # Draw the distance on the color image
            cv2.putText(color_image, f'Distance: {distance:.2f} m', (center_x - 100, center_y - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)

            # Draw a circle at the center
            cv2.circle(color_image, (center_x, center_y), 5, (0, 255, 0), -1)

            # Display the color image
            cv2.imshow('Camera Feed', color_image)

            # Exit the display on pressing 'q'
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

# Example usage
width = 640
height = 480
framerate = 30
autoexposureFrames = 10

# Get backDistance as user input
backDistance = float(input("Enter the scanning distance (backDistance in cm): "))

scan = Scan(width, height, framerate, autoexposureFrames, backDistance)
scan.startPipeline()

# Start the camera feed display in a separate thread
camera_feed_thread = threading.Thread(target=scan.showCameraFeed)
camera_feed_thread.start()

# Take multiple photos at different angles automatically after a set interval
angles = [0, 45, 90, 135, 180, 225, 270, 315, 360]
interval_seconds = 2  # Set the interval between each photo

for angle in angles:
    scan.takeFoto()
    scan.processFoto(angle)
    time.sleep(interval_seconds)  # Wait for the specified interval

# Get the combined point cloud and save it as an STL file
pointcloud = scan.getPointcloud()
o3d.visualization.draw_geometries([pointcloud])  # Visualize the combined point cloud after the whole scan is complete
stl = scan.makeSTL(kpoints=10, stdRatio=0.5, depth=8, iterations=5)
o3d.io.write_triangle_mesh("output.stl", stl)

scan.stopPipeline()
print("3D scanning completed and saved as output.stl")
